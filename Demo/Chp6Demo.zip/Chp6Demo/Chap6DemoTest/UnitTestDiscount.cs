﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Chp6Demo.Models;

namespace Chap6DemoTest
{
    [TestClass]
    public class UnitTestDiscount
    {


        [TestMethod]
        public void Total_Above_100()
        {
            //Arrange
            IDiscountHelper target = new MinDiscountHelper();
            //Action
            decimal discount = target.ApplyDiscount(200);
            //Assert

            Assert.AreEqual(180, discount);
        }
       
        [TestMethod]
        public void Total_Between()
        {
            //Arrange
            IDiscountHelper target = new MinDiscountHelper();
            //Action
            decimal discount = target.ApplyDiscount(50);
            //Assert
            Assert.AreEqual(45, discount);
        }

        [TestMethod]
        public void Total_LessThan_10()
        {
            //Arrange
            IDiscountHelper target = new MinDiscountHelper();
            //Action
            decimal discount = target.ApplyDiscount(0);
            decimal discount1 = target.ApplyDiscount(5);
            
            //Assert
            Assert.AreEqual(0, discount);
            Assert.AreEqual(6, discount);
        }





    }
}
