﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Chp6Demo.Models
{
    public class MinDiscountHelper : IDiscountHelper
    {

        public decimal ApplyDiscount(decimal totalPara)
        {
            //tot < 0
            //if tot > 100, dis = 10%
            //if 10 < tot <= 100, dis = 0%
            //else, dis = 0

            if(totalPara < 0)
            { 
                throw new ArgumentOutOfRangeException();
            }
            else if(totalPara > 100)
            { 
                return totalPara * 0.9M;
            }
            else if(totalPara > 10 && totalPara <= 100)
            { 
                return totalPara - 5;
            }
            else 
            { 
                return totalPara;
            }







        }

    }
}