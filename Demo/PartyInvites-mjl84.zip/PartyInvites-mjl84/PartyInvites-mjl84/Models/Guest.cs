﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PartyInvites_mjl84.Models
{
    public class Guest
    {
        public string Name { set; get; }
        public string Phone { set; get; }
        public string Email { set; get; }

    }
}