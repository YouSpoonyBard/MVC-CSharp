﻿using PartyInvites_mjl84.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PartyInvites_mjl84.Models;

namespace PartyInvites_mjl84.Controllers
{
    //class definition
    public class HomeController:Controller
    {
        //function definition
        //return data type first then function name

        //public string Index()
        //{
        //    return "Hello World";
        //}
        //public ActionResult Index()
        //{
        //    int hour = DateTime.Now.Hour;
        //    string msg = "";

        //    if (hour < 20 )
        //    {
        //        msg = "Good Day!";
        //    }
        //    else
        //    {
        //        msg = "Good Night!";
        //    }

        //    ViewBag.Greeting = msg;

        //    return View();


        //}


    [HttpGet]
        public ActionResult RsvpForm()
        {
            return View();
        }
    [HttpPost]
        public ActionResult RvspForm(Guest aGuest)
    {
        return View("Thanks",aGuest);
    }



    }
}


