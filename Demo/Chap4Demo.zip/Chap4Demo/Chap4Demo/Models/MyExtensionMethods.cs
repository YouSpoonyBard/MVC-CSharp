﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Chap4Demo.Models
{
    public static class MyExtensionMethods
    {
        /* add a new method to the data type (class) IEnumerable<Products> == List<Products
         * first part is the return data type of the function, name of the function
         * the parameter after the "this" means that you created the extension for that data type
         * the input parameter of the extension function is a function
         * the data type of a function is "Func"
         * Func<"input of the function", "output of the function">
         * 
         */
        public static IEnumerable<Product> Filter(this IEnumerable<Product> productEnum, Func<Product, bool> selector)
        {
            foreach (Product p in productEnum)
            {
                if(selector(p))
                {
                    yield return p;
                }
            }
        }   
        /* potential selecter function
         */


        static bool mySelector(Product p)
        {
            return p.Price > 5;
        }


        public static decimal Total(this IEnumerable<Product> productEnum, Func<Product,  decimal> selector)
          {
               decimal sum = 0;
               foreach (Product p in productEnum)
                    {
                     sum += selector(p);
                    }
               return sum;
          }
    }
}