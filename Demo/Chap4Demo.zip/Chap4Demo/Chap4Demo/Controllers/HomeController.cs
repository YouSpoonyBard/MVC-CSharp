﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Chap4Demo.Models;
namespace Chap4Demo.Controllers
{
    public class HomeController:Controller
    {
        public string Index()
        {
            return "Navigate to the URLs: Home/AutoProperty, Home/UseExtension, Home/UseFilterExtension, Home/FindProduct";
        }


        public ViewResult AutoProperty()
        {
            Product mProduct = new Product {ProductID = 100, Name = "Kayak", Description = "A boat for one person", Price = 275M, Category = "Water Sports"};
            return View("Results", (Object)String.Format("Product Name: {0}", mProduct.Name));
        }


        public ViewResult UseExtension()
        {
            ShoppingCart mCart = new ShoppingCart
            {
               account = "mjl84",
               products = new List<Product>
               {
                new Product{ProductID = 1, Name = "Apple", Description = "Red Delicious", Price = 2M, Category = "Fruit"},
                new Product{ProductID = 2, Name = "Banana", Description = "For size", Price = 10M, Category = "Berry"},
                new Product{ProductID = 3, Name = "Pear", Description = "Only one included", Price = 7M, Category = "Fruit"},
                new Product{ProductID = 4, Name = "Grape", Description = "In the mouth", Price = 4M, Category = "Fruit"}
               }
            };
            decimal total = 0;
            foreach (Product p in mCart.products){
                total = total + p.Price;
            }
            return View("Results", (Object)String.Format("Total: {0:c}", total));
        }


        public ViewResult UseFilterExtension()
        {
            ShoppingCart mCart = new ShoppingCart
            {
                account = "mjl84",
                products = new List<Product>
               {
                new Product{ProductID = 1, Name = "Apple", Description = "Red Delicious", Price = 2.5M, Category = "Fruit"},
                new Product{ProductID = 2, Name = "Banana", Description = "For size", Price = 10.2M, Category = "Berry"},
                new Product{ProductID = 3, Name = "Pear", Description = "Only one included", Price = 7M, Category = "Fruit"},
                new Product{ProductID = 4, Name = "Grape", Description = "In the mouth", Price = 4M, Category = "Fruit"}
               }
            };

            IEnumerable<Product> e = mCart.products.Filter(y=>y.Price > 5);

            decimal total = e.Total(y => y.Price);
            
           

            return View("Results", (Object)String.Format("Total of items over $5: {0:c}", total));
        }

        public ViewResult FindProduct()
        {
            ShoppingCart mCart = new ShoppingCart
            {
                account = "mjl84",
                products = new List<Product>
                {
                new Product{ProductID = 1, Name = "Apple", Description = "Red Delicious", Price = 2.5M, Category = "Fruit"},
                new Product{ProductID = 2, Name = "Banana", Description = "For size", Price = 10.2M, Category = "Berry"},
                new Product{ProductID = 3, Name = "Pear", Description = "Only one included", Price = 7M, Category = "Fruit"},
                new Product{ProductID = 4, Name = "Grape", Description = "In the mouth", Price = 4M, Category = "Fruit"}
                }
            };

            //IEnumerable<Product> e = mCart.products.FindAll(y => y.Price > 10);

            //decimal total = e.Sum(y => y.Price);
         
            //return View("Results", (Object)String.Format("Total: {0:c}", total));

            var query = from y in mCart.products
                        // select new { y.ProductID, y.Price };
                        where y.Price > 10
                        select y;
            decimal total = query.ToList().Sum(y => y.Price);

            return View("Results", (Object)String.Format("Total of items over $10: {0:c}", total));
        }

   }
}