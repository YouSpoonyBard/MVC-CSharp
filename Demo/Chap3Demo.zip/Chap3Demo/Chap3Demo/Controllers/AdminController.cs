﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Chap3Demo.Controllers
{
    public class AdminController
    {
    }
}