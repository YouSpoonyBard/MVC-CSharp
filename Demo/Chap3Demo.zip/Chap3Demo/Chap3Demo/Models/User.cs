﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Chap3Demo.Models
{
    public class User
    {
        public class User
        {
            public string loginName { get; set; }
        }
        public interface IRepository
        {
            void Add(User newUser);
            void FetchByLoginUser(string loginName);
            void SubmitChanges();
        }

        public class DefaultRepository : IRepository
        {
            void Add(User newUser) { }
            void FetchByLoginUser(string loginName) { }
            void SubmitChanges() { }
        }
    }
}