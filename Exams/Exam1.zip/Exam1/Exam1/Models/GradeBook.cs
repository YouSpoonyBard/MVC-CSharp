﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Exam1.Models
{
    public class GradeBook
    {
        public int GradeBookId { get; set; }

        public int StudentId { get; set; }

        public List<Exam> exams { get; set; }



    }
}