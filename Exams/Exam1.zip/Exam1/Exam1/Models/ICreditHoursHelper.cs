﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exam1.Models
{
    public interface ICreditHoursHelper
    {
        decimal ApplyAverageScoreTest(decimal Score);



    }
}