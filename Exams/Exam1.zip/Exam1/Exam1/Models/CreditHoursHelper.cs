﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Exam1.Models
{
    public class CreditHoursHelperTest : ICreditHoursHelper
    {
        public decimal ApplyAverageScoreTest(decimal Score)
        {
            if (Score < 0)
            {
                throw new ArgumentOutOfRangeException();
            }
            else if (Score > 100)
            {
                throw new ArgumentOutOfRangeException();
            }
            else if (Score >= 0 && Score < 60)
            {
                return 0;
            }
            else if (Score >= 60 && Score <= 100)
            {
                return 3;
            }
            else
            {
                return 0;
            }
        }


    }



    public static class CreditHoursHelper
    {
        public static decimal ApplyAverageScore(this IEnumerable<Exam> examEnum, Func<Exam, decimal> selector)
        {
            decimal EarnedCreditHours = 0;
            foreach (Exam e in examEnum)
            {
                if (e.Score >= 0 && e.Score < 60)
                {
                    EarnedCreditHours += 0M;
                }
                else if (e.Score >= 60 && e.Score <= 100)
                {
                    EarnedCreditHours += 3M;
                }
                else
                {
                    throw new ArgumentOutOfRangeException();
                }
                return EarnedCreditHours;
            }
        }
    }
}
