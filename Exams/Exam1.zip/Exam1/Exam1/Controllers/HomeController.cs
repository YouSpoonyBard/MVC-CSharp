﻿using Exam1.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;


namespace Exam1.Controllers
{
    public class HomeController : Controller
    {
        public string Index()
        {
            return "Navigate to the URL: Home/UseExtension";
        }

        public ViewResult UseExtension()
        {
            GradeBook gBook = new GradeBook
            {
                GradeBookId = 1,
                StudentId = 1,
                exams = new List<Exam>
                {
                    new Exam{ExamId = 1, Name = "Jack", Score = 70},
                    new Exam{ExamId = 2, Name = "Jill", Score = 52}

                }
            };
            IEnumerable<Exam> e = gBook.exams;
            decimal EarnedCreditHours = e.ApplyAverageScore(y => y.Score);

            decimal chours = 0;
            foreach (Exam i in gBook.exams)
            {
                chours += EarnedCreditHours;
            }
            return View("Results", (Object)String.Format("Credit Hours Earned: {0}", chours));

        }
    }
}