﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Exam1.Models;

namespace Exam1.Tests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void LessThanSixty()
        {
            //arange
            ICreditHoursHelper target = new CreditHoursHelperTest();
            //action
            decimal chours = target.ApplyAverageScoreTest(50);
            //assert
            Assert.AreEqual(0, chours);


        }

    [TestMethod]

    public void GreaterThanSixty()
        {
            ICreditHoursHelper target = new CreditHoursHelperTest();
            decimal chours = target.ApplyAverageScoreTest(70);
            Assert.AreEqual(3, chours);
        }
    }

}
