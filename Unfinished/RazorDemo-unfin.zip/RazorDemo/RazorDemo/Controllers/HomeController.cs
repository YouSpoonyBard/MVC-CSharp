﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using RazorDemo.Models;

namespace RazorDemo.Controllers
{

   
    public class HomeController : Controller
    {
        Product myProduct = new Product { ProductID = 1, Name = "Kayak", Price = 278.50M};

        public ActionResult Index()
        {
            ViewBag.Discount = true;
            return View(myProduct);
        }


        public ActionResult DemoTable()
        {
            return View(myProduct);
        }

    }
}