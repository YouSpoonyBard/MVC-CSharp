﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RazorDemo.Models
{
    public class Product
    {
        public int ProductID { set; get; }
        public string Name { set; get; }
        public decimal Price { set; get; }

    }
}