﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Hw2_mjl84.Models;


namespace Hw2_mjl84.Controllers
{
    public class HomeController : Controller
    {
        public string Index()
        {
            return "Navigate to ____";
        }

        public ViewResult UseExtension
        {
            ShoppingCart mCart = new ShoppingCart
        }




    }
}