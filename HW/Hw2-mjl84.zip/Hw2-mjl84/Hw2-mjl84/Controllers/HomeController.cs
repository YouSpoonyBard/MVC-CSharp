﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Hw2_mjl84.Models;


namespace Hw2_mjl84.Controllers
{
    public class HomeController : Controller
    {
        public string Index()
        {
            return "Navigate to  Home/UseExtension";
        }

        public ViewResult UseExtension()
        {
            ShoppingCart mCart = new ShoppingCart
        {
            CartID = 1,
            products = new List<Product>
            {
                new Product{ProductID = 1, Name = "One", Description = "First", Weight = 2M, Price = 4.5M},
                new Product{ProductID = 2, Name = "Two", Description = "Second", Weight = 12M, Price = 4.5M},
                new Product{ProductID = 3, Name = "Three", Description = "Third", Weight = 24M, Price = 4.5M},
                new Product{ProductID = 4, Name = "Four", Description = "Fourth", Weight = 35M, Price = 4.5M}
            }
        };

            IEnumerable<Product> e = mCart.products;
            decimal shipping = e.ApplyWeight(y => y.Weight);


            decimal total = 0;
            foreach (Product p in mCart.products)
            {
                total += shipping + p.Price;
            }

            return View("Results", (Object)String.Format("Total: {0:c}", total));

        }

    }
}