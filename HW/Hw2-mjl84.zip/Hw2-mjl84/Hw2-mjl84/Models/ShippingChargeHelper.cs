﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Hw2_mjl84.Models
{
    public static class ShippingChargeHelper
    {
        public static IEnumerable<Product> Filter(this IEnumerable<Product> productEnum, Func<Product, bool> selector)
        {
            foreach (Product p in productEnum)
            {
                if (selector(p))
                {
                    yield return p;
                }
            }
        }

        public static decimal ApplyWeight(this IEnumerable<Product> productEnum, Func<Product, decimal> selector)
        {
            decimal shipping = 0;
            foreach (Product p in productEnum)
            {
                if (p.Weight < 0)
                {
                    shipping += 0;
                }
                else if(p.Weight >= 0 && p.Weight < 15)
                {
                    shipping += 5 + p.Weight * .1M;
                }
                else if(p.Weight >= 15 && p.Weight < 30)
                {
                    shipping += 10 + p.Weight * .2M;
                }
                else if (p.Weight >= 30 && p.Weight < 50)
                {
                    shipping += 15 + p.Weight * .25M;
                }
                else
                {
                    shipping += 20 + p.Weight * .5M;
                }
            }
            return shipping;
        }


      

    }
}