﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Hw2_mjl84.Models
{
    public class ShoppingCart
    {

        public int CartID { get; set; }

        public List<Product> products { get; set; }


    }
}