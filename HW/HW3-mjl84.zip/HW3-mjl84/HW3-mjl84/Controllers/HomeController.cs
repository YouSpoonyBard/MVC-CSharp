﻿using HW3_mjl84.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace HW3_mjl84.Controllers
{
    public class HomeController:Controller
    {
        
        public ActionResult Index()
        {
            
            return View();

        }

   [HttpGet]
            public PartialViewResult Menu()
        {
            IEnumerable<string> types = HospitalRepository.Current.GetAll().
                Select(x => x.Type).Distinct().OrderBy(y => y);
            return PartialView(types);
        }

        public ViewResult List(string type)
   {
       return View(HospitalRepository.Current.GetAll().Where(
           h => type == null || h.Type == type).ToList()
           );
   }

    }
   
  
   
}