﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HW3_mjl84.Models
{
    public class HospitalRepository
    {
        private static HospitalRepository rep = new HospitalRepository();

        public static HospitalRepository Current
        {
            get
            {
                return rep;
            }
        }


        private List<Hospital> data = new List<Hospital>
        {
            new Hospital{Id = 1, Name = "Mayo Clinic", City = "Rochester", State = "Minnesota", Zip = "11111", NumberOfBeds = 1, Type = "General"},
        
            new Hospital{Id = 2, Name = "Cleveland Clinic", City = "Cleveland", State = "Ohio", Zip = "22222", NumberOfBeds = 2, Type = "Children"},
            
            new Hospital{Id = 3, Name = "John Hopkins", City = "Baltimore", State = "Maryland", Zip = "33333", NumberOfBeds = 3, Type = "Research"},
        
            new Hospital{Id = 4, Name = "UCLA Medical", City = "Los Angelos", State = "California", Zip = "44444", NumberOfBeds = 4, Type = "General"},
            
            new Hospital{Id = 5, Name = "UCSF Medical", City = "San Fransico", State = "Califonia", Zip = "55555", NumberOfBeds = 5, Type = "Children"},
        };

        public IEnumerable<Hospital> GetAll()
        {
            return data;
        }


    }
}