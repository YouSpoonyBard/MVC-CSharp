﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HW3_mjl84.Models
{
    public class Hospital
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Zip { get; set; }
        public int NumberOfBeds { get; set; }
        public string Type { get; set; }

    }
}